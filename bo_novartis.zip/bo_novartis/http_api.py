from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Any, Dict
from bayesian_optimization import get_next_exps
from exp import run_exp
import uvicorn

app = FastAPI()

class ExpData(BaseModel):
    condition: List
    outcomes: List
    q: int
    goal: List[Dict]
    num_of_init: int
    design_space: List[Dict]
    reaction: str

@app.post("/get-next-exps")
async def next_exps(data: ExpData):
    return get_next_exps(data.model_dump())

@app.post("/run-exp")
async def exp(data: ExpData):
    return run_exp(data.model_dump())

if __name__ == '__main__':
    uvicorn.run(app="http_api:app", host="0.0.0.0", port=123)
