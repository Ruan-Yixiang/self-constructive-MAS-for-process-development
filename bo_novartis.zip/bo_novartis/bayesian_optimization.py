import torch
import numpy as np
from botorch.models import SingleTaskGP
from botorch.fit import fit_gpytorch_model
from gpytorch.mlls import ExactMarginalLogLikelihood
from botorch.acquisition import qExpectedImprovement
from botorch.optim import optimize_acqf_mixed, optimize_acqf
from botorch.sampling.samplers import SobolQMCNormalSampler
from Kernel import MixedSingleTaskGP
from sklearn.metrics import r2_score
from skopt.utils import normalize_dimensions
from skopt.space import Real, Categorical, Space
from transformer import transform, i_transform





def data2space(space_info):
    para = []
    for j in space_info:
        if j['type'] == 'continuous':
            para.append(Real(j['range'][0], j['range'][1], name=j['name']))
    for j in space_info:
        if j['type'] == 'categorical':
            para.append(Categorical(j['range'], name=j['name']))
    space = Space(normalize_dimensions(para))
    return space



def get_next_exps(data):
    space_data = data['design_space']
    space = data2space(space_data)
    # reaction = data['reaction']
    # space = get_space(reaction)
    goal = data['goal']
    condition = data['condition']
    initialization_number = data['num_of_init']
    if condition:
        x = transform(space.transform(condition), space)
        y = data['outcomes']
        q = data['q']
        train_x = torch.tensor(x)
        train_y = torch.tensor(y).unsqueeze(1)
        if len(goal) == 1:
            if goal[0]["target"] != 'max':
                train_y = -1 * train_y
        x_dim = train_x.size()[1]
        if not space.is_real:
            cat_index = []
            n_real = 0
            for j, i in enumerate(space.dimensions):
                para_type = str(type(i)).split('.')[-1][0:-2]
                if para_type == 'Categorical':
                    cat_index.append([j, len(i.bounds)])
                elif para_type == 'Real':
                    n_real += 1
            n_cat = n_real
            for i in cat_index:
                n_cat += i[1]
            cat_mat = np.eye(cat_index[0][1])
            if len(cat_index) > 1:
                for i in cat_index[1:]:
                    cat_mat_temp = np.ones((cat_mat.shape[0] * i[1], cat_mat.shape[1] + i[1]))
                    for k, j in enumerate(cat_mat):
                        cat_mat_temp[k * i[1]: (k + 1) * i[1], :] = np.hstack(
                            (np.repeat(np.array([j]), repeats=i[1], axis=0), np.eye(i[1])))
                    cat_mat = cat_mat_temp
            fixed_features_list = []
            for m in cat_mat:
                cat_dict = {}
                for o, n in enumerate(range(n_real, n_cat)):
                    cat_dict[n] = m[o]
                fixed_features_list.append(cat_dict)
        if space.is_categorical:
            length = 3.0
            sign = -1
            i = 0
            while 1:
                if 0 < length < 6:
                    length += i * sign * 0.5
                    sign = sign * -1
                else:
                    length = (i + 1) * 0.5
                gp = MixedSingleTaskGP(train_x, train_y, cat_dims=list(range(n_real, n_cat)), prior_l=length)
                mll = ExactMarginalLogLikelihood(gp.likelihood, gp)
                fit_gpytorch_model(mll)
                mean = gp(train_x).mean
                train_y_n = train_y.detach().numpy().flatten()
                mean = mean.detach().numpy()
                loss = r2_score(train_y_n, mean)
                i += 1
                if loss > 0.999 or length >= 15:
                    break
        elif space.is_real:
            gp = SingleTaskGP(train_x, train_y)
            mll = ExactMarginalLogLikelihood(gp.likelihood, gp)
            fit_gpytorch_model(mll)
        else:
            gp = MixedSingleTaskGP(train_x, train_y, cat_dims=list(range(n_real, n_cat)))
            mll = ExactMarginalLogLikelihood(gp.likelihood, gp)
            fit_gpytorch_model(mll)
        sampler = SobolQMCNormalSampler(2048)
        bounds = torch.stack([torch.zeros(x_dim), torch.ones(x_dim)])
        qEI = qExpectedImprovement(gp, best_f=torch.max(train_y), sampler=sampler)

        if not space.is_real:
            candidate, acq_value = optimize_acqf_mixed(
                qEI, bounds=bounds, q=q, fixed_features_list=fixed_features_list, num_restarts=20, raw_samples=200)
        else:
            candidate, acq_value = optimize_acqf(qEI, bounds=bounds, q=q, num_restarts=20, raw_samples=200)
        candidate = space.inverse_transform(i_transform(candidate, space))
    else:
        candidate =space.rvs(n_samples=initialization_number)

    def format_float(num):
        return round(num, 3)
    formatted_candidate = []
    for sublist in candidate:
        formatted_sublist = [format_float(item) if isinstance(item, float) else item for item in sublist]
        formatted_candidate.append(formatted_sublist)

    for i in formatted_candidate:
        condition.append(i)
    return data


